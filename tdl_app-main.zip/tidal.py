import argparse
import os
import re
import subprocess
import threading
from pathlib import Path

import requests
import tidalapi
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from tidalapi import Quality

IMG_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Referer": "https://listen.tidal.com/",
}

# Windows limita las rutas a 260 caracteres (259 utiles + el nulo final)
MAX_PATH_LEN = 259

# Portada incrustada.
#  - El FiiO X1 II tiene una pantalla de 320x240: se incrusta una imagen de
#    como mucho 640 px (2x la pantalla) en JPEG calidad 7, ~30-70 KB.
#  - Windows (Media Foundation) no abre un FLAC con una JPEG de ~4 MB o mas
#    incrustada (probado: 3,48 MB abre, 4,21 MB no), asi que asi se evita
#    tambien ese problema.
EMBED_PIC_MAX_DIM = 640
EMBED_PIC_QUALITY = 7
MAX_EMBED_PIC_BYTES = 1_500_000
EMBED_PIC_FILTER = f"scale='min({EMBED_PIC_MAX_DIM},iw)':-2"


class TidalDownloader:
    def __init__(self, session_file: Path):
        self.session = tidalapi.Session()
        self.session.login_session_file(session_file, do_pkce=True)
        self._no_cover = set()  # ids de albumes sin portada (evita reintentos)

    @property
    def audio_quality(self):
        return self.session.audio_quality

    @audio_quality.setter
    def audio_quality(self, value):
        self.session.audio_quality = value

    def _get_stream_urls(self, track):
        stream = track.get_stream()
        manifest = stream.get_stream_manifest()

        if stream.is_bts:
            urls = manifest.get_urls()
            if urls:
                return urls, stream.audio_quality, False

        if stream.is_mpd:
            hls = manifest.get_hls()
            if hls:
                urls = re.findall(r"^https?://.*\.mp4\?.*$", hls, re.MULTILINE)
                if urls:
                    return urls, stream.audio_quality, True

        raise ValueError(f"No se pudieron obtener URLs para: {track.name}")

    @staticmethod
    def _notify(queue, msg: str):
        if queue is None:
            print(msg)
        else:
            queue.put({"msg": msg})

    def _get_cover(self, track, folder: Path, queue=None):
        """Descarga cover.jpg en la carpeta del album (una sola vez).

        Devuelve la ruta del archivo o None si no hay portada disponible.
        """
        album = track.album
        if album is None:
            return None

        cover_path = folder / "cover.jpg"
        try:
            if cover_path.exists() and cover_path.stat().st_size > 0:
                return cover_path

            if not album.cover and album.id:
                # Al pedir una pista suelta el album viene sin portada
                if album.id in self._no_cover:
                    return None
                album = self.session.album(album.id)
            if not album.cover:
                if album.id:
                    self._no_cover.add(album.id)
                return None

            resp = requests.get(album.image("origin"), headers=IMG_HEADERS, timeout=30)
            resp.raise_for_status()
            if not resp.content:
                return None

            tmp = folder / f".cover.{os.getpid()}.{threading.get_ident()}.tmp"
            tmp.write_bytes(resp.content)
            tmp.replace(cover_path)
            self._notify(queue, f"\U0001f5bc️ Portada guardada: {folder.name}/cover.jpg")
            return cover_path
        except Exception as e:
            self._notify(queue, f"\u26a0\ufe0f Portada no descargada en {folder.name}: {e}")
            return None

    @staticmethod
    def _has_cover_art(flac_path: Path) -> bool:
        """True si el FLAC ya lleva una imagen incrustada."""
        try:
            probe = subprocess.run(
                [
                    "ffprobe", "-v", "error",
                    "-select_streams", "v:0",
                    "-show_entries", "stream=codec_type",
                    "-of", "csv=p=0",
                    str(flac_path),
                ],
                capture_output=True,
                text=True,
            )
            return probe.returncode == 0 and bool(probe.stdout.strip())
        except OSError:
            return False

    @staticmethod
    def _embedded_picture_info(flac_path: Path) -> tuple:
        """(ancho, bytes) de la imagen incrustada; (0, -1) si no se puede medir."""
        try:
            probe = subprocess.run(
                [
                    "ffprobe", "-v", "error",
                    "-select_streams", "v:0",
                    "-show_entries", "stream=width:packet=size",
                    "-of", "default",
                    str(flac_path),
                ],
                capture_output=True,
                text=True,
            )
            ancho, tam = 0, -1
            for line in probe.stdout.splitlines():
                if line.startswith("width="):
                    ancho = int(line.split("=", 1)[1])
                elif line.startswith("size="):
                    bloque = int(line.split("=", 1)[1])
                    tam = bloque if tam < 0 else tam + bloque
            return ancho, tam
        except (OSError, ValueError):
            return 0, -1

    def _embed_cover(self, flac_path: Path, cover_path: Path, queue=None):
        """Incrusta cover.jpg como caratula dentro del FLAC.

        Se reduce y recomprime: una JPEG de 4 MB incrustada hace que Windows
        no pueda abrir el FLAC, y el FiiO X1 II solo necesita 320x240.
        """
        if not (flac_path.exists() and cover_path.exists()):
            return
        if self._has_cover_art(flac_path):
            ancho, tam = self._embedded_picture_info(flac_path)
            if tam < 0 or (ancho <= EMBED_PIC_MAX_DIM and tam <= MAX_EMBED_PIC_BYTES):
                return  # ya lleva una portada ligera

        # Nombre corto y único: el nombre del FLAC ya puede estar en el límite
        # de 260 caracteres, y ".tmp.flac" extra lo desbordaría.
        tmp = flac_path.with_name(f".embed-{os.getpid()}-{threading.get_ident()}.flac")
        try:
            subprocess.run(
                [
                    "ffmpeg", "-v", "error", "-y",
                    "-i", str(flac_path),
                    "-i", str(cover_path),
                    "-map", "0:a:0",
                    "-map", "1:v:0",
                    "-c:a", "copy",
                    "-vf", EMBED_PIC_FILTER,
                    "-c:v", "mjpeg",
                    "-q:v", str(EMBED_PIC_QUALITY),
                    "-disposition:v:0", "attached_pic",
                    str(tmp),
                ],
                capture_output=True,
                check=True,
                text=True,
            )
            tmp.replace(flac_path)
            self._notify(queue, f"\U0001f5bc️ Portada incrustada en {flac_path.name}")
        except subprocess.CalledProcessError as e:
            if tmp.exists():
                tmp.unlink()
            detail = (e.stderr or "").strip().splitlines()[-1] if e.stderr else str(e)
            self._notify(queue, f"\u26a0\ufe0f Portada no incrustada en {flac_path.name}: {detail}")
        except Exception as e:
            if tmp.exists():
                tmp.unlink()
            self._notify(queue, f"\u26a0\ufe0f Portada no incrustada en {flac_path.name}: {e}")

    @staticmethod
    def _sanitize_path(name: str) -> str:
        invalid_chars = r'<>:"/\|?*'
        return "".join(c for c in name if c not in invalid_chars)

    @staticmethod
    def _shorten(text: str, max_len: int) -> str:
        """Recorta text a max_len caracteres para no rebase MAX_PATH de Windows."""
        if max_len <= 0:
            return text[:1]
        if len(text) <= max_len:
            return text
        return text[: max_len - 1].rstrip(" ") + "\u2026"

    @classmethod
    def _build_folder(cls, base: Path, artist: str, album: str) -> tuple:
        """Ruta Artista/Album recortada si excede MAX_PATH.

        Devuelve (carpeta, True/False si hubo que recortar).
        """
        reserve = 40  # deja sitio para "NN - titulo.flac"
        if len(str(base)) + 1 + len(artist) + 1 + len(album) + reserve <= MAX_PATH_LEN:
            return base / artist / album, False

        room = MAX_PATH_LEN - reserve - len(str(base)) - 2
        short_artist = cls._shorten(artist, max(1, room // 2))
        short_album = cls._shorten(album, max(1, room - len(short_artist)))
        return base / short_artist / short_album, True

    def download_track(self, track_id: str, output_dir: str = "./TIDAL"):
        track = self.session.track(track_id)
        if not track:
            print(f"\u274c Pista no encontrada: {track_id}")
            return

        artist = self._sanitize_path(track.artist.name)
        album = self._sanitize_path(track.album.name)
        title = self._sanitize_path(track.name)

        folder, folder_cut = self._build_folder(Path(output_dir), artist, album)
        folder.mkdir(parents=True, exist_ok=True)
        if folder_cut:
            self._notify(None, f"\u2702 Carpeta recortada (l\u00edmite de Windows): {folder.name}")

        num = track.track_num or 1
        stem = f"{int(num):02d} - {title}"
        short_stem = self._shorten(stem, MAX_PATH_LEN - len(str(folder)) - 1 - len(".flac"))
        if short_stem != stem:
            self._notify(None, f"\u2702 Nombre recortado (l\u00edmite de Windows): {short_stem}.flac")
        temp_path = folder / f"{short_stem}.m4a"
        flac_path = folder / f"{short_stem}.flac"

        cover_path = self._get_cover(track, folder)

        if flac_path.exists():
            if cover_path:
                self._embed_cover(flac_path, cover_path)
            print(f"\u23ed\ufe0f  Saltado (ya existe): {flac_path.name}")
            return

        try:
            urls, quality, is_hls = self._get_stream_urls(track)
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "audio/*",
                "Origin": "https://listen.tidal.com",
            }

            if not is_hls:
                url = urls[0]
                resp = requests.get(url, headers=headers, stream=True)
                resp.raise_for_status()
                total = int(resp.headers.get("content-length", 0))
                with Progress(
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    DownloadColumn(),
                    TransferSpeedColumn(),
                    TimeRemainingColumn(),
                    transient=True,
                ) as progress:
                    task = progress.add_task(f"\U0001f4e5 {title}", total=total)
                    with open(temp_path, "wb") as f:
                        for chunk in resp.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                                progress.update(task, advance=len(chunk))
            else:
                total_segments = len(urls)
                with Progress(
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TextColumn("{task.completed}/{task.total} segmentos"),
                    transient=True,
                ) as progress:
                    task = progress.add_task(f"\U0001f4e5 {title}", total=total_segments)
                    with open(temp_path, "wb") as f:
                        for url in urls:
                            resp = requests.get(url, headers=headers)
                            resp.raise_for_status()
                            f.write(resp.content)
                            progress.update(task, advance=1)

            subprocess.run(
                ["ffmpeg", "-i", str(temp_path), "-c:a", "flac", "-y", str(flac_path)],
                capture_output=True,
                check=True,
            )
            temp_path.unlink()
            if cover_path:
                self._embed_cover(flac_path, cover_path)
            print(f"\u2705 Guardado: {flac_path} ({quality})")
        except Exception as e:
            print(f"\u274c Error descargando {track.name}: {e}")
            if temp_path.exists():
                temp_path.unlink()
            if flac_path.exists():
                flac_path.unlink()

    def download_album(self, album_id: str, output_dir: str = "./TIDAL"):
        album = self.session.album(album_id)
        if not album:
            print("\u274c Album no encontrado")
            return

        print(f"\U0001f4c1 Procesando album: {album.name}")
        for track in album.tracks():
            self.download_track(track.id, output_dir)

    def download_playlist(self, playlist_id: str, output_dir: str = "./TIDAL"):
        playlist = self.session.playlist(playlist_id)
        if not playlist:
            print("\u274c Playlist no encontrada")
            return

        print(f"\U0001f4cb Procesando playlist: {playlist.name}")
        for track in playlist.tracks():
            self.download_track(track.id, output_dir)

    def search(self, query: str, limit: int = 10):
        results = self.session.search(query, models=[tidalapi.Track], limit=limit)
        tracks = results.get("tracks", [])
        if not tracks:
            print("\U0001f50d No se encontraron resultados")
            return

        print(f"\n\U0001f3b5 Resultados para '{query}':")
        for i, track in enumerate(tracks, 1):
            print(f"{i}. {track.name} - {track.artist.name} [{track.id}]")

        return tracks


def main():
    parser = argparse.ArgumentParser(description="Tidal Downloader (OAuth)")
    parser.add_argument(
        "--session-file",
        default="./tidal-session.json",
        help="Archivo de sesion OAuth (default: ./tidal-session.json)",
    )
    parser.add_argument(
        "--quality",
        choices=["LOW", "HIGH", "LOSSLESS", "HI_RES_LOSSLESS"],
        default="HI_RES_LOSSLESS",
        help="Calidad de audio (default: HI_RES_LOSSLESS)",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    search_parser = subparsers.add_parser("search", help="Buscar pistas")
    search_parser.add_argument("query", help="Termino de busqueda")
    search_parser.add_argument("--limit", type=int, default=10, help="Limite de resultados")

    track_parser = subparsers.add_parser("track", help="Descargar una pista")
    track_parser.add_argument("track_id", help="ID de la pista")
    track_parser.add_argument("--output", default="./TIDAL", help="Directorio de salida")

    album_parser = subparsers.add_parser("album", help="Descargar un album")
    album_parser.add_argument("album_id", help="ID del album")
    album_parser.add_argument("--output", default="./TIDAL", help="Directorio de salida")

    playlist_parser = subparsers.add_parser("playlist", help="Descargar una playlist")
    playlist_parser.add_argument("playlist_id", help="ID de la playlist")
    playlist_parser.add_argument("--output", default="./TIDAL", help="Directorio de salida")

    args = parser.parse_args()

    quality_map = {
        "LOW": Quality.low_96k,
        "HIGH": Quality.low_320k,
        "LOSSLESS": Quality.high_lossless,
        "HI_RES_LOSSLESS": Quality.hi_res_lossless,
    }

    downloader = TidalDownloader(Path(args.session_file))
    downloader.audio_quality = quality_map[args.quality]

    if args.command == "search":
        downloader.search(args.query, args.limit)
    elif args.command == "track":
        downloader.download_track(args.track_id, args.output)
    elif args.command == "album":
        downloader.download_album(args.album_id, args.output)
    elif args.command == "playlist":
        downloader.download_playlist(args.playlist_id, args.output)


if __name__ == "__main__":
    main()
