# Tidal → FLAC

Descarga música de Tidal en **FLAC** con su portada: un `cover.jpg` en cada carpeta de álbum y la carátula incrustada dentro de cada `.flac`.

Incluye una **interfaz web** (Flask, con progreso en vivo) y una **CLI** con la misma lógica.

> **Aviso**: úsalo solo con contenido al que tengas derecho y respeta los términos de servicio de Tidal.

---

## Requisitos

| Requisito | Detalle |
| --- | --- |
| Python | 3.9 o superior (probado con 3.14) |
| `ffmpeg` + `ffprobe` | en el `PATH` (probado con ffmpeg 9.0.2, build de Gyan) |
| Cuenta de Tidal | con suscripción que permita calidad lossless / hi-res |

Comprueba que ambos están en el `PATH`:

```bash
ffmpeg -version
ffprobe -version
```

En Windows, si falla:

```powershell
winget install Gyan.FFmpeg
```

`ffprobe` es imprescindible: se usa para saber si un FLAC ya lleva portada incrustada y para medir su tamaño antes de reescribirlo.

## Instalación

```bash
git clone https://github.com/<usuario>/<repo>.git
cd <repo>
python -m venv venv

# Linux / macOS
source venv/bin/activate
# Windows
venv\Scripts\activate

pip install -r requirements.txt
```

## Interfaz web

```bash
python webapp.py
```

Abre sola `http://127.0.0.1:5000`.

1. Al cargar, la página inicia la sesión con tu cuenta de Tidal (PKCE en el navegador) y guarda el token en `tidal-session.json`.
2. Busca por **Canciones / Álbumes / Artistas**.
3. Marca lo que quieras, elige la carpeta de salida (por defecto `./TIDAL`) y pulsa **Descargar**.
4. El progreso llega en vivo por SSE: un error se muestra en pantalla **sin cortar** la cola de descarga, y la conexión sigue abierta hasta el final.

Salida:

```
TIDAL/
└── Artista/
    └── Álbum/
        ├── 01 - Canción.flac
        ├── 02 - Canción.flac
        └── cover.jpg
```

La calidad en la web va fija a `HI_RES_LOSSLESS` (Tidal devuelve la máxima disponible para cada pista).

## CLI

```bash
python tidal.py search "soledad pastorutti" --limit 10
python tidal.py track <track_id> --output ./TIDAL
python tidal.py album <album_id> --output ./TIDAL
python tidal.py playlist <playlist_id> --output ./TIDAL
```

Opciones globales:

| Opción | Por defecto | Valores |
| --- | --- | --- |
| `--session-file` | `./tidal-session.json` | ruta del token OAuth |
| `--quality` | `HI_RES_LOSSLESS` | `LOW`, `HIGH`, `LOSSLESS`, `HI_RES_LOSSLESS` |

## Portadas

* **`cover.jpg`** en cada carpeta de álbum, a resolución original (imagen `origin` de Tidal, normalmente 3000×3000), para el PC.
* La **misma carátula incrustada** en cada `.flac`, pero reducida a **máximo 640 px** en JPEG calidad 7 (**~30–80 KB**).

Se comprime a propósito por dos motivos:

1. **FiiO X1 II** (pantalla de 320×240): con 640 px —2× la pantalla— se ve nítida y el archivo pesa casi nada.
2. **Windows no abre un FLAC con una JPEG de ~4 MB incrustada.** Comprobado empíricamente: con 3,48 MB sí abre, con 4,21 MB no. A resolución completa la carátula llega a 4,4 MB.

Si un FLAC ya tiene una portada más ancha o más pesada, **se vuelve a embeber sola** en la siguiente pasada (no hay que re-descargar nada). Los valores están en `webapp.py` y `tidal.py`:

```python
EMBED_PIC_MAX_DIM   = 640        # px máximos de la imagen incrustada
EMBED_PIC_QUALITY   = 7          # calidad JPEG
MAX_EMBED_PIC_BYTES = 1_500_000  # por encima de esto se vuelve a embeber
EMBED_PIC_FILTER    = f"scale='min({EMBED_PIC_MAX_DIM},iw)':-2"
```

El filtro con `min()` evita ampliar portadas que ya sean más pequeñas que 640 px.

## Detalles en Windows

* **Rutas**: máximo de **259 caracteres** (`MAX_PATH_LEN`). Artista, álbum y título se recortan con `…` en lugar de alargar la ruta: Windows corta en 260, y por encima de ahí `ffmpeg` escribe bien pero Python falla al renombrar o borrar.
* **Ya descargado**: si el FLAC existe no se vuelve a descargar el audio, pero sí se le comprueba la portada.
* **Temporales**: los nombres son cortos (`.embed-<pid>-<hilo>.flac`) para que la conversión de portada no desborde el límite de ruta.
* **Sin portada**: los álbumes sin carátula se anotan en una lista interna para no reintentarlos en cada pasada.

## Estructura del repositorio

```
webapp.py             Servidor Flask: API REST + arranque en el puerto 5000
tidal.py              CLI: search / track / album / playlist
templates/index.html  Interfaz: búsqueda, selección y progreso en vivo (SSE)
requirements.txt      Dependencias
.gitignore            Excluye venv/, TIDAL/, tidal-session.json, __pycache__/
README.md             Este archivo
```

## No subir al repositorio

`.gitignore` ya excluye:

```
venv/
__pycache__/
*.pyc
tidal-session.json    # tus tokens OAuth
.DS_Store
TIDAL/                # música descargada
Descargas/
```

Nada de eso debe subirse: `tidal-session.json` contiene credenciales y `TIDAL/` es material con derechos de autor.
