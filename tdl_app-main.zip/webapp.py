import json as jsonlib
import os
import re
import subprocess
import threading
from pathlib import Path
from queue import Empty, Queue

import requests
import tidalapi
from flask import Flask, Response, jsonify, render_template, request
from tidalapi import Quality

QUALITY_MAP = {
    "LOW": Quality.low_96k,
    "HIGH": Quality.low_320k,
    "LOSSLESS": Quality.high_lossless,
    "HI_RES_LOSSLESS": Quality.hi_res_lossless,
}

app = Flask(__name__)
downloader = None
progress_queues = {}


IMG_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Referer": "https://listen.tidal.com/",
}

# Windows limita las rutas a 260 caracteres (259 utiles + el nulo final)
MAX_PATH_LEN = 259

# Portada incrustada.
#  - El FiiO X1 II tiene una pantalla de 320x240: se incrusta una imagen de
#    como mucho 640 px (2x la pantalla) en JPEG calidad 7, ~30-70 KB.
#  - Windows (Media Foundation) no abre un FLAC con una JPEG de ~4 MB o mas
#    incrustada (probado: 3,48 MB abre, 4,21 MB no), asi que asi se evita
#    tambien ese problema.
EMBED_PIC_MAX_DIM = 640
EMBED_PIC_QUALITY = 7
MAX_EMBED_PIC_BYTES = 1_500_000
EMBED_PIC_FILTER = f"scale='min({EMBED_PIC_MAX_DIM},iw)':-2"


class TidalDownloader:
    def __init__(self, session_file: Path):
        self.session = tidalapi.Session()
        self.session.login_session_file(session_file, do_pkce=True)
        self.session.audio_quality = Quality.hi_res_lossless
        self._no_cover = set()  # ids de albumes sin portada (evita reintentos)

    def search_tracks(self, query: str, limit: int = 20):
        results = self.session.search(query, models=[tidalapi.Track], limit=limit)
        return [
            {
                "id": t.id,
                "title": t.name,
                "artist": t.artist.name,
                "album": t.album.name,
                "duration": t.duration,
                "type": "track",
            }
            for t in results.get("tracks", [])
        ]

    def search_albums(self, query: str, limit: int = 20):
        results = self.session.search(query, models=[tidalapi.Album], limit=limit)
        albums = []
        for a in results.get("albums", []):
            albums.append(
                {
                    "id": a.id,
                    "title": a.name,
                    "artist": a.artist.name if a.artist else "Desconocido",
                    "year": str(a.release_date.year) if a.release_date else "",
                    "tracks": a.num_tracks,
                    "type": "album",
                }
            )
        return albums

    def search_artists(self, query: str, limit: int = 20):
        results = self.session.search(query, models=[tidalapi.Artist], limit=limit)
        return [
            {
                "id": a.id,
                "title": a.name,
                "type": "artist",
            }
            for a in results.get("artists", [])
        ]

    def get_artist_albums(self, artist_id: str):
        artist = self.session.artist(artist_id)
        albums = artist.get_albums()
        return [
            {
                "id": a.id,
                "title": a.name,
                "year": str(a.release_date.year) if a.release_date else "",
                "tracks": a.num_tracks,
            }
            for a in albums
        ]

    def get_album_tracks(self, album_id: str):
        album = self.session.album(album_id)
        return {
            "title": album.name,
            "artist": album.artist.name,
            "tracks": [
                {
                    "id": t.id,
                    "title": t.name,
                    "num": t.track_num or i + 1,
                    "duration": t.duration,
                }
                for i, t in enumerate(album.tracks())
            ],
        }

    def _get_stream_urls(self, track):
        stream = track.get_stream()
        manifest = stream.get_stream_manifest()

        if stream.is_bts:
            urls = manifest.get_urls()
            if urls:
                return urls, stream.audio_quality, False

        if stream.is_mpd:
            hls = manifest.get_hls()
            if hls:
                urls = re.findall(r"^https?://.*\.mp4\?.*$", hls, re.MULTILINE)
                if urls:
                    return urls, stream.audio_quality, True

        raise ValueError(f"No se pudieron obtener URLs para: {track.name}")

    def _get_cover(self, track, folder: Path, queue: Queue):
        """Descarga cover.jpg en la carpeta del album (una sola vez).

        Devuelve la ruta del archivo o None si no hay portada disponible.
        """
        album = track.album
        if album is None:
            return None

        cover_path = folder / "cover.jpg"
        try:
            if cover_path.exists() and cover_path.stat().st_size > 0:
                return cover_path

            if not album.cover and album.id:
                # Al pedir una pista suelta el album viene sin portada
                if album.id in self._no_cover:
                    return None
                album = self.session.album(album.id)
            if not album.cover:
                if album.id:
                    self._no_cover.add(album.id)
                return None

            resp = requests.get(album.image("origin"), headers=IMG_HEADERS, timeout=30)
            resp.raise_for_status()
            if not resp.content:
                return None

            tmp = folder / f".cover.{os.getpid()}.{threading.get_ident()}.tmp"
            tmp.write_bytes(resp.content)
            tmp.replace(cover_path)
            queue.put({"msg": f"\U0001f5bc️ Portada guardada: {folder.name}/cover.jpg"})
            return cover_path
        except Exception as e:
            queue.put({"msg": f"\u26a0\ufe0f Portada no descargada en {folder.name}: {e}"})
            return None

    @staticmethod
    def _sanitize_path(name: str) -> str:
        invalid_chars = r'<>:"/\|?*'
        return "".join(c for c in name if c not in invalid_chars)

    @staticmethod
    def _shorten(text: str, max_len: int) -> str:
        """Recorta text a max_len caracteres para no rebase MAX_PATH de Windows."""
        if max_len <= 0:
            return text[:1]
        if len(text) <= max_len:
            return text
        return text[: max_len - 1].rstrip(" ") + "\u2026"

    @classmethod
    def _build_folder(cls, base: Path, artist: str, album: str) -> tuple:
        """Ruta Artista/Album recortada si excede MAX_PATH.

        Devuelve (carpeta, True/False si hubo que recortar).
        """
        reserve = 40  # deja sitio para "NN - titulo.flac"
        if len(str(base)) + 1 + len(artist) + 1 + len(album) + reserve <= MAX_PATH_LEN:
            return base / artist / album, False

        room = MAX_PATH_LEN - reserve - len(str(base)) - 2
        short_artist = cls._shorten(artist, max(1, room // 2))
        short_album = cls._shorten(album, max(1, room - len(short_artist)))
        return base / short_artist / short_album, True

    @staticmethod
    def _has_cover_art(flac_path: Path) -> bool:
        """True si el FLAC ya lleva una imagen incrustada."""
        try:
            probe = subprocess.run(
                [
                    "ffprobe", "-v", "error",
                    "-select_streams", "v:0",
                    "-show_entries", "stream=codec_type",
                    "-of", "csv=p=0",
                    str(flac_path),
                ],
                capture_output=True,
                text=True,
            )
            return probe.returncode == 0 and bool(probe.stdout.strip())
        except OSError:
            return False

    @staticmethod
    def _embedded_picture_info(flac_path: Path) -> tuple:
        """(ancho, bytes) de la imagen incrustada; (0, -1) si no se puede medir."""
        try:
            probe = subprocess.run(
                [
                    "ffprobe", "-v", "error",
                    "-select_streams", "v:0",
                    "-show_entries", "stream=width:packet=size",
                    "-of", "default",
                    str(flac_path),
                ],
                capture_output=True,
                text=True,
            )
            ancho, tam = 0, -1
            for line in probe.stdout.splitlines():
                if line.startswith("width="):
                    ancho = int(line.split("=", 1)[1])
                elif line.startswith("size="):
                    bloque = int(line.split("=", 1)[1])
                    tam = bloque if tam < 0 else tam + bloque
            return ancho, tam
        except (OSError, ValueError):
            return 0, -1

    def _embed_cover(self, flac_path: Path, cover_path: Path, queue: Queue):
        """Incrusta cover.jpg como caratula dentro del FLAC.

        Se reduce y recomprime: una JPEG de 4 MB incrustada hace que Windows
        no pueda abrir el FLAC, y el FiiO X1 II solo necesita 320x240.
        """
        if not (flac_path.exists() and cover_path.exists()):
            return
        if self._has_cover_art(flac_path):
            ancho, tam = self._embedded_picture_info(flac_path)
            if tam < 0 or (ancho <= EMBED_PIC_MAX_DIM and tam <= MAX_EMBED_PIC_BYTES):
                return  # ya lleva una portada ligera

        # Nombre corto y único: el nombre del FLAC ya puede estar en el límite
        # de 260 caracteres, y ".tmp.flac" extra lo desbordaría.
        tmp = flac_path.with_name(f".embed-{os.getpid()}-{threading.get_ident()}.flac")
        try:
            subprocess.run(
                [
                    "ffmpeg", "-v", "error", "-y",
                    "-i", str(flac_path),
                    "-i", str(cover_path),
                    "-map", "0:a:0",
                    "-map", "1:v:0",
                    "-c:a", "copy",
                    "-vf", EMBED_PIC_FILTER,
                    "-c:v", "mjpeg",
                    "-q:v", str(EMBED_PIC_QUALITY),
                    "-disposition:v:0", "attached_pic",
                    str(tmp),
                ],
                capture_output=True,
                check=True,
                text=True,
            )
            tmp.replace(flac_path)
        except subprocess.CalledProcessError as e:
            if tmp.exists():
                tmp.unlink()
            detail = (e.stderr or "").strip().splitlines()[-1] if e.stderr else str(e)
            queue.put({"msg": f"\u26a0\ufe0f Portada no incrustada en {flac_path.name}: {detail}"})
        except Exception as e:
            if tmp.exists():
                tmp.unlink()
            queue.put({"msg": f"\u26a0\ufe0f Portada no incrustada en {flac_path.name}: {e}"})

    def download_track(self, track_id: str, output_dir: str, queue: Queue):
        try:
            track = self.session.track(track_id)
            if not track:
                queue.put({"error": f"Pista no encontrada: {track_id}"})
                return

            artist = self._sanitize_path(track.artist.name)
            album_name = self._sanitize_path(track.album.name)
            title = self._sanitize_path(track.name)
            folder, folder_cut = self._build_folder(Path(output_dir), artist, album_name)
            folder.mkdir(parents=True, exist_ok=True)
            if folder_cut:
                queue.put({
                    "msg": f"\u2702 Carpeta recortada (l\u00edmite de Windows): {folder.name}"
                })
            num = track.track_num or 1
            stem = f"{int(num):02d} - {title}"
            short_stem = self._shorten(
                stem, MAX_PATH_LEN - len(str(folder)) - 1 - len(".flac")
            )
            if short_stem != stem:
                queue.put({
                    "msg": f"\u2702 Nombre recortado (l\u00edmite de Windows): {short_stem}.flac"
                })
            temp_path = folder / f"{short_stem}.m4a"
            flac_path = folder / f"{short_stem}.flac"

            cover_path = self._get_cover(track, folder, queue)

            if flac_path.exists():
                if cover_path:
                    self._embed_cover(flac_path, cover_path, queue)
                queue.put({"msg": f"\u23ed\ufe0f Saltado: {title}"})
                return

            urls, quality, is_hls = self._get_stream_urls(track)
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "audio/*",
                "Origin": "https://listen.tidal.com",
            }
            queue.put({"progress": 0, "msg": f"\U0001f4e5 Descargando: {title}"})

            if not is_hls:
                resp = requests.get(urls[0], headers=headers, stream=True)
                resp.raise_for_status()
                total = int(resp.headers.get("content-length", 0))
                downloaded = 0
                with open(temp_path, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if total:
                                queue.put({"progress": int(downloaded / total * 80)})
            else:
                total_segs = len(urls)
                with open(temp_path, "wb") as f:
                    for i, url in enumerate(urls):
                        resp = requests.get(url, headers=headers)
                        resp.raise_for_status()
                        f.write(resp.content)
                        queue.put({"progress": int((i + 1) / total_segs * 80)})

            queue.put({"progress": 85, "msg": "\U0001f504 Convirtiendo a FLAC..."})
            subprocess.run(
                ["ffmpeg", "-i", str(temp_path), "-c:a", "flac", "-y", str(flac_path)],
                capture_output=True,
                check=True,
            )
            temp_path.unlink()
            if cover_path:
                self._embed_cover(flac_path, cover_path, queue)
            queue.put({"msg": f"\u2705 {title} ({quality})"})
        except Exception as e:
            queue.put({"error": str(e)})
            if "temp_path" in locals() and temp_path.exists():
                temp_path.unlink()
            if "flac_path" in locals() and flac_path.exists():
                flac_path.unlink()

    @staticmethod
    def _sanitize_path(name: str) -> str:
        invalid_chars = r'<>:"/\|?*'
        return "".join(c for c in name if c not in invalid_chars)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/login")
def api_login():
    global downloader
    try:
        downloader = TidalDownloader(Path("./tidal-session.json"))
        return jsonify({"ok": True, "user": str(downloader.session.user.id)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/api/search/<kind>")
def api_search(kind: str):
    if not downloader:
        return jsonify({"ok": False, "error": "No autenticado"}), 400
    try:
        query = request.args.get("q", "")
        limit = int(request.args.get("limit", 20))
        if kind == "tracks":
            results = downloader.search_tracks(query, limit)
        elif kind == "albums":
            results = downloader.search_albums(query, limit)
        elif kind == "artists":
            results = downloader.search_artists(query, limit)
        else:
            return jsonify({"ok": False, "error": "Tipo invalido"}), 400
        return jsonify({"ok": True, "results": results})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/artist/<artist_id>/albums")
def api_artist_albums(artist_id: str):
    if not downloader:
        return jsonify({"ok": False, "error": "No autenticado"}), 400
    try:
        albums = downloader.get_artist_albums(artist_id)
        return jsonify({"ok": True, "albums": albums})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/album/<album_id>/tracks")
def api_album_tracks(album_id: str):
    if not downloader:
        return jsonify({"ok": False, "error": "No autenticado"}), 400
    try:
        data = downloader.get_album_tracks(album_id)
        return jsonify({"ok": True, **data})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


progress_id_counter = 0
progress_id_lock = threading.Lock()


@app.route("/api/download", methods=["POST"])
def api_download():
    global progress_id_counter
    if not downloader:
        return jsonify({"ok": False, "error": "No autenticado"}), 400
    data = request.get_json()
    items = data.get("items", [])
    output = data.get("output", "./TIDAL")
    with progress_id_lock:
        progress_id_counter += 1
        pid = f"dl_{progress_id_counter}"
    q: Queue = Queue()
    progress_queues[pid] = q

    def worker():
        for item in items:
            if item["type"] == "track":
                downloader.download_track(item["id"], output, q)
            elif item["type"] == "album":
                album = downloader.session.album(item["id"])
                for track in album.tracks():
                    downloader.download_track(track.id, output, q)
        q.put(None)

    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"ok": True, "progress_id": pid})


@app.route("/api/progress/<progress_id>")
def api_progress(progress_id: str):
    def generate():
        q = progress_queues.get(progress_id)
        if not q:
            yield f"data: {jsonlib.dumps({'error': 'not found'})}\n\n"
            return
        while True:
            try:
                msg = q.get(timeout=30)
                if msg is None:
                    yield f"data: {jsonlib.dumps({'done': True, 'msg': 'Completado'})}\n\n"
                    break
                yield f"data: {jsonlib.dumps(msg)}\n\n"
            except Empty:
                yield f"data: {jsonlib.dumps({'keepalive': True})}\n\n"

    return Response(generate(), mimetype="text/event-stream")


if __name__ == "__main__":
    import threading
    import webbrowser

    threading.Timer(1.5, lambda: webbrowser.open("http://127.0.0.1:5000")).start()
    app.run(debug=False, port=5000)
